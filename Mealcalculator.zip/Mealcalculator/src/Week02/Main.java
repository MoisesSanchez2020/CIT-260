package Week02;

import java.util.Scanner;

public class Main {


    /**
     *
     * Write a short Java program that does the following:
     *
     * Tells the user what the program does.
     * Prompts the user to enter a value for the cost of their meal.
     * Gets the user's input and saves it in a variable declared as a double.
     * Prompts the user to enter a percentage value for the tip.
     * Gets the user's input and saves it in a variable declared as a double.
     * Calculates the value of the tip, using the percentage entered by the user.
     * Calculates the tax on the meal. The tax rate is 3.2%.
     * Calculates the total bill = meal cost + tip + tax.
     * Outputs the tip, the tax, and the total value of the bill.
     *       All values will be formatted to show a dollar sign and 2 digits after the decimal point.
     * Outputs a goodbye message.
     * @param args
     */

    public static void main(String[] args) {
	   displayMensaje();
	   double precios = userPrompt("Enter the cost of the Meal:");
       double PercentTip = userPrompt("Enter the tio percentage:");
       double precTip = calcuTip(precios, PercentTip);
       double taxTotal  =  calcuTax(precios);
       double total = calcuTotal(precios, precTip, taxTotal);
       displayExpenses(precTip, taxTotal, total);
       endMessege();
    }

    /**
     * This is the intro message
     */

    public static void displayMensaje(){
        System.out.println(" Given the price of a meal and a percentage to use for the tip, ");
          System.out.println("this program calculates the tip, the tax, and the total amount of the bill.");
      }


    /**
     *
     * @param message to be show to the user
     * @return number that the user entered
     */

    public static double userPrompt(String message){
        Scanner input = new Scanner(System.in);
        System.out.print(message + "" ) ;

        return input.nextDouble();
      }

    /**
     *
     *
     * @param precios the amount of the total cost
     * @return the total plus tax
     */


    public static double calcuTax(double precios){
        return precios * 0.032;
      }


      public static double calcuTip(double precios, double tip){
        double percent = tip / 100.0;
        return  precios * percent;
      }

      public static double calcuTotal(double precios, double tip, double tax){
        return precios + tip + tax;
      }

      public static void displayExpenses(double tip, double tax, double total){
        System.out.println("\nThe tip is $" + String.format("%.2f", tip));
        System.out.println("the tax is $" + String.format("%.2f", tax));
        System.out.println("The total bill is $" + String.format("%.2f",total));
      }


      public static void endMessege(){
        System.out.println("Goodbye");
      }



}
